# comdig_pract_DiffCod_PLL
Es una practica de gnuradio que abarca aspectos de canal inalámbrico como el uso del PLL para corregir la desviación aleatoria de fase que produce el canal, así como la codificación diferencial para corregir la ambieguedad que puede resultar despues de aplicar el PLL
Enlace a la guía práctica: https://docs.google.com/document/d/1HR7g_bj2S7cb0d-UJhCuNAQDLU1y1sSb0apcO09ax78/edit?usp=sharing¿
